# MineServer

MineServer é um aplicativo desktop Windows em Go e Fyne v2 para administrar um servidor Paper Minecraft Java com acesso Bedrock por Geyser/Floodgate. A aplicação cria o ambiente, baixa as dependências, mantém proxies TCP/UDP em espera e inicia o Paper apenas quando chega a primeira conexão.

## Arquitetura

```text
MineServer_Project/
├── main.go                         # bootstrap e injeção de dependências
├── go.mod
├── go.sum
├── FyneApp.toml
├── README.md
└── internal/
    ├── api/
    │   └── client.go               # PaperMC, Modrinth e downloads atômicos
    ├── gui/
    │   ├── gui.go                  # cinco abas Fyne e marshaling com fyne.Do
    │   └── link_controls.go        # cards Java/Bedrock, copiar e Shutdown
    ├── i18n/
    │   └── i18n.go                 # traduções PT-BR/EN thread-safe
    ├── manager/
    │   ├── manager.go              # estado, eventos e ciclo de vida
    │   ├── server.go               # Paper, downloads, comandos e jogadores
    │   ├── storage.go              # configurações, propriedades, bans e arquivos
    │   ├── types.go                # contratos e eventos imutáveis
    │   └── manager_test.go
    └── proxy/
        ├── service.go              # proxies TCP/UDP e standby
        └── service_test.go
```

As dependências seguem em uma única direção: `main → gui → manager → api/proxy`. O proxy não conhece Fyne nem manipula widgets. Eventos produzidos em background chegam à GUI como snapshots, e toda alteração visual é encaminhada por `fyne.Do`.

## Recursos

- Cinco abas: status, console, jogadores, controles e configurações/arquivos.
- Painel de links com cards Java/Bedrock, versões suportadas, badges ON/OFF e cópia para a área de transferência.
- Estado visual derivado dos descritores reais dos sockets, sem conexões de sondagem que acordariam o Paper.
- Shutdown confirmado que cancela sessões, fecha sockets, aguarda goroutines e libera as duas portas.
- Proxy Java TCP em `0.0.0.0`, procurando porta livre a partir de `25565`.
- Proxy Bedrock UDP em `0.0.0.0`, procurando porta livre a partir de `19132`.
- Paper e Geyser isolados em portas internas de loopback.
- Inicialização no primeiro pacote e parada graciosa após 15 minutos sem jogadores ou tráfego.
- Download assíncrono de Paper, Geyser, Floodgate, Chunky e CoreProtect.
- Barra de progresso, cancelamento e downloads atômicos.
- Buffer circular de 2.500 logs para limitar o uso de memória.
- Logs estruturados por nível, componente, horário e nome da instância.
- Console Paper via stdin, OP, kick, banimento temporário e pardon.
- Internacionalização dinâmica em português e inglês.
- Persistência de nome, idioma, versão e `max-players` em `server/config.json`.
- Atualização segura de `server.properties` e `plugins/Geyser-Spigot/config.yml`.
- Encerramento coordenado por `context.Context`, `WaitGroup` e fechamento dos sockets.

## Pré-requisitos no Windows

- Windows 10/11 de 64 bits.
- Go 1.23 ou posterior: <https://go.dev/dl/>.
- Java 21 ou posterior no `PATH`: <https://adoptium.net/>.
- GCC/MinGW-w64 para o CGO usado pelo Fyne: <https://www.msys2.org/>.

No terminal MSYS2 UCRT64:

```bash
pacman -Syu
pacman -S --needed mingw-w64-ucrt-x86_64-gcc
```

Adicione `C:\msys64\ucrt64\bin` ao `PATH` e confirme:

```powershell
go version
java -version
gcc --version
```

## Testar

```powershell
go mod download
go test -tags ci ./...
go vet -tags ci ./...
```

Para verificar concorrência durante o desenvolvimento:

```powershell
go test -race -tags ci ./internal/manager ./internal/proxy ./internal/api ./internal/i18n
```

## Compilar MineServer.exe

```powershell
$env:CGO_ENABLED = "1"
go build -buildvcs=false -trimpath -ldflags="-H=windowsgui -s -w" -o MineServer.exe .
```

Também é possível usar a ferramenta oficial do Fyne:

```powershell
go install fyne.io/tools/cmd/fyne@latest
fyne build --target windows --release -o MineServer.exe
```

## Primeira execução

1. Execute `MineServer.exe` em uma pasta gravável.
2. Escolha a versão do Minecraft ou mantenha “Mais recente estável”.
3. Ajuste o nome da instância e `max-players`.
4. Clique em **PLAY** e aguarde os downloads.
5. Compartilhe o endereço Java ou Bedrock mostrado na tela.

O botão **Desligar Links** encerra imediatamente os proxies e conexões existentes, mas não finaliza o Paper. Clique em **PLAY** para reservar portas e ativar os links novamente.

Para conexões pela Internet, configure no roteador o redirecionamento da porta TCP exibida para Java e da porta UDP exibida para Bedrock, apontando para o IPv4 local do computador. Libere também o executável e o Java no Firewall do Windows.

## Arquivos gerados

```text
server/
├── config.json
├── eula.txt
├── server.jar
├── server.properties
├── mineserver-paper-version.json
├── mineserver-bans.json
└── plugins/
    ├── Geyser-Spigot.jar
    ├── Floodgate-Spigot.jar
    ├── Chunky.jar
    └── CoreProtect.jar
```

Faça backup da pasta `server` antes de trocar para uma versão anterior do Minecraft.

## Publicar no GitHub Releases

Versione todos os arquivos-fonte, inclusive `go.sum` e a pasta `internal`:

```powershell
git init
git add main.go go.mod go.sum FyneApp.toml README.md internal
git commit -m "Release MineServer v2.0.0"
git tag v2.0.0
```

Gere o binário, confira o hash e publique ambos no Release:

```powershell
Get-FileHash .\MineServer.exe -Algorithm SHA256
gh release create v2.0.0 .\MineServer.exe --title "MineServer v2.0.0" --generate-notes
```

Um executável sem assinatura pode acionar o Microsoft Defender SmartScreen. Para distribuição pública, use um certificado de assinatura de código.
