package main

import (
	"fyne.io/fyne/v2"
	"fyne.io/fyne/v2/app"
	"fyne.io/fyne/v2/theme"

	"mineserver/internal/gui"
	"mineserver/internal/manager"
)

const (
	appID    = "io.github.mineserver.app"
	appTitle = "MineServer"
)

func main() {
	application := app.NewWithID(appID)
	application.Settings().SetTheme(theme.DarkTheme())
	window := application.NewWindow(appTitle)
	window.Resize(fyne.NewSize(1180, 760))
	window.SetMaster()

	service := manager.New(".")
	userInterface := gui.New(application, window, service)
	window.SetContent(userInterface.Build())

	window.SetCloseIntercept(func() {
		window.SetCloseIntercept(nil)
		go func() {
			if err := service.Close(); err != nil {
				service.Log("error", "shutdown", "falha durante encerramento", err)
			}
			fyne.Do(window.Close)
		}()
	})
	window.ShowAndRun()
}
